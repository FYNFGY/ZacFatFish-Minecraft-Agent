# ZFF MCP Server（便携版）

这个目录**不需要 npm install**：`node_modules` 已经打好包。

手动启动（插件也能自动起）：
```
node src/server.js --http --port 57610 --workspace "<你的工作目录>"
```

- `/health` —— 存活探测
- `/instances` —— 实例列表（含游戏名 username），给 DSH 插件用
- `/mcp` —— MCP 端点（streamable-http，stdio 用 `--stdio`）

构建时间：2026-11-06T13:08:37.227Z